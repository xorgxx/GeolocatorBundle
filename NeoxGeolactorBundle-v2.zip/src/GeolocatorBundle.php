<?php

namespace GeolocatorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GeolocatorBundle extends Bundle
{
}
