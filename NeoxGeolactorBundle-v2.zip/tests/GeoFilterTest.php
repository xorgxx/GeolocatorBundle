<?php

use Pest\PestArtisan;
use GeolocatorBundle\Attribute\GeoFilter;

it('works', function () {
    // TODO: ajouter des tests PestPHP
    expect(true)->toBeTrue();
});
